package Atividade2;

public class Equalizador {
    private String cheiro = "cheiro";
    private String solta = "solta";
    private String instrucao = "instrucao";

    public void transportar() {
        System.out.println(cheiro + "," + solta + "," + instrucao);
    }

    public static void main(String[] args) {
        Equalizador meuEqualizador = new Equalizador();
        meuEqualizador.transportar();

    }
}