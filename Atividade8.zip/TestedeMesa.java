package org.example;

import java.util.Locale;
import java.util.Scanner;

public class TestedeMesa {
    public static void main(String[] args) {

    Scanner sc = new Scanner(System.in);
    sc.useLocale(Locale.US);

    double SUB,X,API,P1,E1,E2;

        System.out.println("SUB(Prova Substitutiva):");
        SUB = sc.nextDouble();

        System.out.println("X(Atividades extras):");
        X = sc.nextDouble();

        System.out.println("API:");
        API = sc.nextDouble();

        System.out.println("P1( Prova 1):");
        P1 = sc.nextDouble();

        System.out.println("E1(Entrega 1):");
        E1 = sc.nextDouble();

        System.out.println("E2(Entrega 2):");
        E2 = sc.nextDouble();

        double parteAPI = 0;
        double S = P1*0.5 + E1*0.2 + E2*0.3 + X + SUB*0.15;
        double mediaBase = S * 0.5;
        if (S > 5.9) {
        parteAPI = API*0.5;
        } else {
        parteAPI = 0.0;
        }
        double mediaFinal = mediaBase + parteAPI;

        System.out.printf("Media Final: %.2f%n",+mediaFinal);



    }
}